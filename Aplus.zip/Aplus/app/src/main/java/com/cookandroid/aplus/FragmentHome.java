package com.cookandroid.aplus;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class FragmentHome extends Fragment {

    private Button StartBtn, StopBtn,ResetBtn;
    private TextView TimeTextView, RecordTextView,SubjectTitle;
    private Thread timeThread = null;
    private Boolean isRunning = true;
    private EditText SubjectName;
    private String start;
    private String end;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        StartBtn = (Button) view.findViewById(R.id.btn_start);
        StopBtn = (Button) view.findViewById(R.id.btn_stop);
        ResetBtn=(Button)view.findViewById(R.id.btn_reset);
        TimeTextView = (TextView) view.findViewById(R.id.timeView);
        RecordTextView = (TextView) view.findViewById(R.id.recordView);
        SubjectTitle=(TextView)view.findViewById(R.id.SubjectTitle);
        SubjectName=(EditText)view.findViewById(R.id.subjectName);


        StartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimeTextView.setText("00:00");
                timeThread = new Thread(new timeThread());
                SubjectTitle.setText(SubjectName.getText().toString()+" 공부 중");
                TimeZone timezone = TimeZone.getTimeZone("Etc/GMT-9");
                TimeZone.setDefault(timezone);
                SimpleDateFormat formater = new SimpleDateFormat("HH시mm분ss초", Locale.KOREA);
                Date current = new Date();
                start = formater.format(current);
                timeThread.start();
            }
        });

        StopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat formater = new SimpleDateFormat("HH시mm분ss초", Locale.KOREA);
                Date current = new Date();
                end = formater.format(current);

                RecordTextView.setText("_______________________________________"+"\n"+RecordTextView.getText() + "과목:"+SubjectName.getText().toString()+"\t"+"공부 시간:"+TimeTextView.getText().toString() + "\n"+
                        "공부 시작:"+start+"\n"+"공부 끝:"+end+"\n");
                timeThread.interrupt();
                SubjectTitle.setText("포기하지 마세요!");
                SubjectName.setText(null);


            }
        });

        ResetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               RecordTextView.setText("");
                SubjectName.setText(null);
                timeThread.interrupt();
            }
        });

        return view;
    }

    @SuppressLint("HandlerLeak")
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int sec = (msg.arg1 / 100) % 60;
            int min = (msg.arg1 / 100) / 60;
            int hour = (msg.arg1 / 100) / 360;
            //1000이 1초 1000*60 은 1분 1000*60*10은 10분 1000*60*60은 한시간

            @SuppressLint("DefaultLocale") String result = String.format("%02d:%02d:%02d", hour, min, sec);
            TimeTextView.setText(result);

        }
    };

    public class timeThread implements Runnable {
        @Override
        public void run() {
            int i = 0;
            while (true) {
                while (isRunning) { //일시정지를 누르면 멈춤
                    Message msg = new Message();
                    msg.arg1 = i++;
                    handler.sendMessage(msg);

                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        handler.post(new Runnable(){
                            @Override
                            public void run() {
                                TimeTextView.setText("");
                                TimeTextView.setText("00:00:00");
                            }
                        });
                        return; // 인터럽트 받을 경우 return
                    }
                }
            }
        }
    }

}
