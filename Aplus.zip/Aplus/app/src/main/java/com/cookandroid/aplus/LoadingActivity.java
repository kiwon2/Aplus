package com.cookandroid.aplus;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;

import com.cookandroid.aplus.R;

public class LoadingActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);//activity_Loading 출력
        startLoading();
    }

    //로딩을 위한 메소드
    private void startLoading() {
        Handler handler = new Handler();//Handler의 속성을 이용해 일정 시간동안 로딩화면을 출력함
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 2000);//로딩화면 시간(2초)
    }
}