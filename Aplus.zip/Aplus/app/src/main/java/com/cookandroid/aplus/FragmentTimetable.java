package com.cookandroid.aplus;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FragmentTimetable extends Fragment { //Fragment를 상속받음
    Button button1;
    View dialogView;
    EditText subject,time,tableid;
    private AutoResizeTextView table91,table92,table93,table94,table95,table101,table102,table103,table104,table105,table111,table112,table113,table114,table115,table121,table122,table123,table124,table125;
    AutoResizeTextView table11,table12,table13,table14,table15;
    AutoResizeTextView table21,table22,table23,table24,table25;
    AutoResizeTextView table31,table32,table33,table34,table35;
    AutoResizeTextView table41,table42,table43,table44,table45;
    AutoResizeTextView table51,table52,table53,table54,table55;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_timetable, container, false);

        button1 = (Button) view.findViewById(R.id.button1);

        table91 = (AutoResizeTextView) view.findViewById(R.id.monday0);
        table92 = (AutoResizeTextView) view.findViewById(R.id.tuseday0);
        table93 = (AutoResizeTextView) view.findViewById(R.id.wednesday0);
        table94 = (AutoResizeTextView) view.findViewById(R.id.thursday0);
        table95 = (AutoResizeTextView) view.findViewById(R.id.friday0);

        table101 = (AutoResizeTextView) view.findViewById(R.id.monday1);
        table102 = (AutoResizeTextView) view.findViewById(R.id.tuseday1);
        table103 = (AutoResizeTextView) view.findViewById(R.id.wednesday1);
        table104 = (AutoResizeTextView) view.findViewById(R.id.thursday1);
        table105 = (AutoResizeTextView) view.findViewById(R.id.friday1);

        table111 = (AutoResizeTextView) view.findViewById(R.id.monday2);
        table112 = (AutoResizeTextView) view.findViewById(R.id.tuseday2);
        table113 = (AutoResizeTextView) view.findViewById(R.id.wednesday2);
        table114 = (AutoResizeTextView) view.findViewById(R.id.thursday2);
        table115 = (AutoResizeTextView) view.findViewById(R.id.friday2);

        table121 = (AutoResizeTextView) view.findViewById(R.id.monday3);
        table122 = (AutoResizeTextView) view.findViewById(R.id.tuseday3);
        table123 = (AutoResizeTextView) view.findViewById(R.id.wednesday3);
        table124 = (AutoResizeTextView) view.findViewById(R.id.thursday3);
        table125 = (AutoResizeTextView) view.findViewById(R.id.friday3);

        table11 = (AutoResizeTextView) view.findViewById(R.id.monday4);
        table12 = (AutoResizeTextView) view.findViewById(R.id.tuseday4);
        table13 = (AutoResizeTextView) view.findViewById(R.id.wednesday4);
        table14 = (AutoResizeTextView) view.findViewById(R.id.thursday4);
        table15 = (AutoResizeTextView) view.findViewById(R.id.friday4);

        table21 = (AutoResizeTextView) view.findViewById(R.id.monday5);
        table22 = (AutoResizeTextView) view.findViewById(R.id.tuseday5);
        table23 = (AutoResizeTextView) view.findViewById(R.id.wednesday5);
        table24 = (AutoResizeTextView) view.findViewById(R.id.thursday5);
        table25 = (AutoResizeTextView) view.findViewById(R.id.friday5);

        table31 = (AutoResizeTextView) view.findViewById(R.id.monday6);
        table32 = (AutoResizeTextView) view.findViewById(R.id.tuseday6);
        table33 = (AutoResizeTextView) view.findViewById(R.id.wednesday6);
        table34 = (AutoResizeTextView) view.findViewById(R.id.thursday6);
        table35 = (AutoResizeTextView) view.findViewById(R.id.friday6);

        table41 = (AutoResizeTextView) view.findViewById(R.id.monday7);
        table42 = (AutoResizeTextView) view.findViewById(R.id.tuseday7);
        table43 = (AutoResizeTextView) view.findViewById(R.id.wednesday7);
        table44 = (AutoResizeTextView) view.findViewById(R.id.thursday7);
        table45 = (AutoResizeTextView) view.findViewById(R.id.friday7);

        table51 = (AutoResizeTextView) view.findViewById(R.id.monday8);
        table52 = (AutoResizeTextView) view.findViewById(R.id.tuseday8);
        table53 = (AutoResizeTextView) view.findViewById(R.id.wednesday8);
        table54 = (AutoResizeTextView) view.findViewById(R.id.thursday8);
        table55 = (AutoResizeTextView) view.findViewById(R.id.friday8);

        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialogView = (View) View.inflate(getActivity(), R.layout.dialog, null);
                AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
                dlg.setTitle("과목 추가");
                dlg.setView(dialogView);

                dlg.setPositiveButton("확인 ",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {

                                tableid = (EditText) dialogView.findViewById(R.id.ok);

                                if (tableid.getText().toString().equals("모바일프로그래밍")) {
                                    table101.setBackgroundColor(Color.RED);
                                    table111.setBackgroundColor(Color.RED);
                                    table121.setBackgroundColor(Color.RED);
                                    table101.setText("모바일");
                                    table111.setText("성결관");
                                    table121.setText("406");
                                } else if (tableid.getText().toString().equals("현대인과기독교")) {
                                    table32.setBackgroundColor(Color.BLUE);
                                    table42.setBackgroundColor(Color.BLUE);
                                    table52.setBackgroundColor(Color.BLUE);
                                    table32.setText("기독교");
                                    table42.setText("중생관");
                                    table52.setText("101");
                                } else if (tableid.getText().toString().equals("소프트웨어공학")) {
                                    table33.setBackgroundColor(Color.RED);
                                    table43.setBackgroundColor(Color.RED);
                                    table53.setBackgroundColor(Color.RED);
                                    table33.setText("소웨공");
                                    table43.setText("성결관");
                                    table53.setText("406");
                                } else if (tableid.getText().toString().equals("인공지능")) {
                                    table92.setBackgroundColor(Color.GREEN);
                                    table102.setBackgroundColor(Color.GREEN);
                                    table112.setBackgroundColor(Color.GREEN);
                                    table92.setText("인지");
                                    table102.setText("성결관");
                                    table112.setText("404");
                                } else if (tableid.getText().toString().equals("컴퓨터알고리즘")) {
                                    table94.setBackgroundColor(Color.BLUE);
                                    table104.setBackgroundColor(Color.BLUE);
                                    table114.setBackgroundColor(Color.BLUE);
                                    table94.setText("컴알");
                                    table104.setText("성결관");
                                    table114.setText("405");
                                } else {
                                    Toast tMsg = Toast.makeText(getActivity(), "저장 된 과목이 없습니다 다른 과목을 입력해주세요", Toast.LENGTH_SHORT);
                                    tMsg.show();

                                }
                            }
                        });


                dlg.setNegativeButton("취소", null);
                dlg.show();
            }


        });
        return view;  }

}
