package com.cookandroid.aplus;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class FragmentStatistic extends Fragment {//Fragment를 상속받음
    private TextView CheckLog;
    private Button Start;
    private  String day;
    private String filename;
    private String checkTime;
    private Button Reset;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_statistic, container, false);// Inflater를 통해 각 프래그먼트에 해당하는 레이아웃 리소스를 View로 반환

        CheckLog=(TextView)view.findViewById(R.id.checklog);//접속로그를 출력할 텍스트뷰 선언
        Start=(Button)view.findViewById(R.id.start);//출석 버튼 선언
        Reset=(Button)view.findViewById(R.id.reset);//초기화 버튼 선언

        TimeZone timezone = TimeZone.getTimeZone("Etc/GMT-9");//한국은 표준시각보다 9시간이 빠른 시간대를 사용
        TimeZone.setDefault(timezone);
        SimpleDateFormat formater = new SimpleDateFormat("yyyy__MM__dd", Locale.KOREA);//시간, 날짜를 원하는 포맷으로 출력
        Date current = new Date();
        day = formater.format(current);
        filename= day+".txt";//하루동안의 접속 기록들을 작성하기 위해 파일 이름을 접속 날짜로 설정함

        String str=Check(filename);
        CheckLog.setText(str);//접속 날짜의 txt파일을 CheckLog에 출력

        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat formater = new SimpleDateFormat("yyyy년 MM월 dd일 HH시mm분ss초", Locale.KOREA);//시간, 날짜를 원하는 포맷으로 출력
                Date current = new Date();
                checkTime = formater.format(current);
                CheckLog.setText(CheckLog.getText() +"\n"+checkTime+"에 접속함"+"\n");
                Toast.makeText(getActivity(),checkTime+" 출석완료!",Toast.LENGTH_SHORT).show();//토스트메세지로 버튼 클릭 시각을 보여줌
                try {
                    FileOutputStream outfs=getActivity().openFileOutput(filename, Context.MODE_PRIVATE);
                    String str=CheckLog.getText().toString();;
                    outfs.write(str.getBytes());
                    outfs.close();
                } catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
                    e.printStackTrace();
                } catch (IOException e) {//예외처리
                    e.printStackTrace();
                }
            }
        });

        Reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckLog.setText("");
                try {
                    FileOutputStream outfs=getActivity().openFileOutput(filename, Context.MODE_PRIVATE);
                    String str=CheckLog.getText().toString();
                    outfs.write(str.getBytes());
                    outfs.close();
                    Toast.makeText(getActivity(),"접속기록을 삭제함",Toast.LENGTH_SHORT).show();//토스트메세지로 초기화됨을 보여줌
                } catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
                    e.printStackTrace();
                } catch (IOException e) {//예외처리
                    e.printStackTrace();
                }
            }
        });

        return view;
    }


    String Check(String filename) {//파일 이름을 매개변수로 받는다.
        String CheckLog=null;//읽어온 접속기록을 저장할 문자열 변수와 입력 파일 변수 선언
        FileInputStream infs;
        try {
            infs=getActivity().openFileInput(filename);//접속기록 파일을 열어 입력 파일 스트림에 저장
            byte txt[]=new byte[500];
            infs.read(txt);
            infs.close();
            CheckLog=(new String(txt)).trim();
        } catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
            e.printStackTrace();
        } catch (IOException e) {//예외처리
            e.printStackTrace();
        }
        return CheckLog;
    }
}