package com.cookandroid.aplus;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.zip.Inflater;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


//일정 프래그먼트
public class FragmentCalendar extends Fragment { //Fragment를 상속받음

    DatePicker dp;
    EditText edtDiary;
    Button btnWrite;
    String filename;//파일 이름을 지정할 문자열 변수

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_calendar, container, false);// Inflater를 통해 각 프래그먼트에 해당하는 레이아웃 리소스를 View로 반환

            dp=(DatePicker)view.findViewById(R.id.datePicker);//데이트피커 선언
            edtDiary=(EditText)view.findViewById(R.id.edtDiary);//에디트텍스트 선언
            btnWrite=(Button)view.findViewById(R.id.btnWrite);//버튼 선언


        Calendar cal=Calendar.getInstance();//Calendar클래스를 통해 현재 년, 월, 일 구하기
        int cYear=cal.get(Calendar.YEAR);
        int cMonth=cal.get(Calendar.MONTH);
        int cDay=cal.get(Calendar.DAY_OF_MONTH);

            String filename1= Integer.toString(cYear)+"_"+Integer.toString(cMonth+1)+"_"+Integer.toString(cDay)+".txt";
            String str1=readDiary(filename1);

            edtDiary.setText(str1);
            btnWrite.setEnabled(true);

           dp.init(cYear,cMonth,cDay, new DatePicker.OnDateChangedListener() {//데이트피커를 init메소드로 지정.

               @Override
               public void onDateChanged(DatePicker datePicker, int y, int m, int d) {//onDateChange를 이용하여 날짜가 바뀔시 바뀐 날짜 적용
                   filename=Integer.toString(y)+"_"+ Integer.toString(m+1)+"_"+Integer.toString(d)+".txt";
                   String str=readDiary(filename);
                   edtDiary.setText(str);
                   btnWrite.setEnabled(true);
               }
           });

            btnWrite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {//일정쓰기버튼클릭이벤트
                    try {
                        FileOutputStream outfs=getActivity().openFileOutput(filename, Context.MODE_PRIVATE);
                        String str=edtDiary.getText().toString();
                        outfs.write(str.getBytes());
                        outfs.close();
                        Toast.makeText(getActivity(),filename+"이 저장됨",Toast.LENGTH_SHORT).show();//토스트메세지로 저장됨을 보여줌
                    } catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
                        e.printStackTrace();
                    } catch (IOException e) {//예외처리
                        e.printStackTrace();
                    }
                }
            });
            return view;
        }

        String readDiary(String filename) {//파일 이름을 매개변수로 받는다.
            String diaryStr=null;//읽어온 일정를 저장할 문자열 변수와 입력 파일 변수 선언
            FileInputStream infs;
            try {
                infs=getActivity().openFileInput(filename);//일정 파일을 열어 입력 파일 스트림에 저장
                byte txt[]=new byte[500];
                infs.read(txt);
                infs.close();
                diaryStr=(new String(txt)).trim();
                btnWrite.setText("일정 수정하기");
            } catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
                edtDiary.setHint("일정 없음");
                btnWrite.setText("새로 저장");
            } catch (IOException e) {//예외처리
                e.printStackTrace();
            }
            return diaryStr;//파일 있음->90행 반환, 파일 없음->83행의 null값 반환
        }
    }

