package com.cookandroid.aplus;

import android.annotation.SuppressLint;
import android.content.Context;
import android.icu.text.AlphabeticIndex;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class FragmentHome extends Fragment {//Fragment를 상속받음

    private Button StartBtn, StopBtn,ResetBtn;
    private TextView TimeTextView, RecordTextView,SubjectTitle;
    private Thread timeThread = null;
    private Boolean isRunning = true;
    private EditText SubjectName;
    private String start;
    private String end;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_home, container, false);// Inflater를 통해 각 프래그먼트에 해당하는 레이아웃 리소스를 View로 반환
        super.onCreate(savedInstanceState);
        StartBtn = (Button) view.findViewById(R.id.btn_start);
        StopBtn = (Button) view.findViewById(R.id.btn_stop);
        ResetBtn=(Button)view.findViewById(R.id.btn_reset);
        TimeTextView = (TextView) view.findViewById(R.id.timeView);
        RecordTextView = (TextView) view.findViewById(R.id.recordView);
        SubjectTitle=(TextView)view.findViewById(R.id.SubjectTitle);
        SubjectName=(EditText)view.findViewById(R.id.subjectName);

        String str=readStudyLog("StudyLog.txt");//StudyLog.txt파일 읽기
        RecordTextView.setText(str);//StudyLog.txt파일을 RecordTextView에 출력

        StartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//시작 버튼 클릭 이벤트
                TimeTextView.setText("00:00");
                timeThread = new Thread(new timeThread());//Thread 생성
                SubjectTitle.setText(SubjectName.getText().toString()+" 공부 중");//EditText에 있는 내용을 출력

                TimeZone timezone = TimeZone.getTimeZone("Etc/GMT-9");//한국은 표준시각보다 9시간이 빠른 시간대를 사용
                TimeZone.setDefault(timezone);
                SimpleDateFormat formater = new SimpleDateFormat("HH시mm분ss초", Locale.KOREA);//시간, 날짜를 원하는 포맷으로 출력
                Date current = new Date();
                start = formater.format(current);
                timeThread.start();//타이머 실행(Thread 사용)
            }
        });

        StopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//멈춤 버튼 클릭 이벤트
                SimpleDateFormat formater = new SimpleDateFormat("HH시mm분ss초", Locale.KOREA);//시간, 날짜를 원하는 포맷으로 출력
                Date current = new Date();
                end = formater.format(current);
                RecordTextView.setText(RecordTextView.getText() +"\n"+ "과목:"+SubjectName.getText().toString()+"\n"+"공부 시간:"+TimeTextView.getText().toString() + "\n"+
                        "공부 시작:"+start+"\n"+"공부 끝:"+end+"\n"+"\n");
                try {
                    FileOutputStream outfs=getActivity().openFileOutput("StudyLog.txt", Context.MODE_PRIVATE);
                    String str=RecordTextView.getText().toString();
                    outfs.write(str.getBytes());
                    outfs.close();
                    Toast.makeText(getActivity(),"공부기록이 저장됨",Toast.LENGTH_SHORT).show();//토스트메세지로 저장됨을 보여줌
                } catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
                    e.printStackTrace();
                } catch (IOException e) {//예외처리
                    e.printStackTrace();
                }
                timeThread.interrupt();
                SubjectTitle.setText("포기하지 마세요!");
                SubjectName.setText(null);


            }
        });

        ResetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//초기화버튼 클릭 이벤트
               RecordTextView.setText("");
                try {
                    FileOutputStream outfs=getActivity().openFileOutput("StudyLog.txt", Context.MODE_PRIVATE);
                    String str=RecordTextView.getText().toString();
                    outfs.write(str.getBytes());
                    outfs.close();
                    Toast.makeText(getActivity(),"공부기록을 삭제함",Toast.LENGTH_SHORT).show();//토스트메세지로 초기화됨을 보여줌
                } catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
                    e.printStackTrace();
                } catch (IOException e) {//예외처리
                    e.printStackTrace();
                }
                SubjectName.setText(null);
                timeThread.interrupt();//Thread의 run() 메소드를 정상종료
            }
        });

        return view;
    }

    @SuppressLint("HandlerLeak")
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int sec = (msg.arg1 / 100) % 60;
            int min = (msg.arg1 / 100) / 60;
            int hour = (msg.arg1 / 100) / 360;
            //1000이 1초이므로 1000*60 은 1분, 1000*60*10은 10분, 1000*60*60은 1시간임

            @SuppressLint("DefaultLocale") String result = String.format("%02d:%02d:%02d", hour, min, sec);
            TimeTextView.setText(result);

        }
    };

    public class timeThread implements Runnable {
        @Override
        public void run() {
            int i = 0;
            while (true) {
                while (isRunning) { //일시정지를 누르면 멈춤
                    Message msg = new Message();
                    msg.arg1 = i++;
                    handler.sendMessage(msg);

                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        handler.post(new Runnable(){
                            @Override
                            public void run() {
                                TimeTextView.setText("");
                                TimeTextView.setText("00:00:00");
                            }
                        });
                        return; // 인터럽트 받을 경우 return
                    }
                }
            }
        }
    }
    String readStudyLog(String filename) {//파일 이름을 파라미터로 받음
        String StudyLogStr=null;//읽어온 일기를 저장할 문자열 변수와 입력 파일 변수 선언
        FileInputStream infs;
        try {
            infs=getActivity().openFileInput(filename);//일정(일기) 파일을 열어 입력 파일 스트림에 저장
            byte txt[]=new byte[5000];
            infs.read(txt);
            infs.close();
            StudyLogStr=(new String(txt)).trim();
        }catch (FileNotFoundException e) {//저장된 파일이 없으면 실행
            e.printStackTrace();
        }
        catch (IOException e) {//예외처리
            e.printStackTrace();
        }
        return StudyLogStr;
    }

}
