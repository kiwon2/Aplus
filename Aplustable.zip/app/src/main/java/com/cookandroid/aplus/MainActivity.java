package com.cookandroid.aplus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;


import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private FragmentManager fragmentManager = getSupportFragmentManager();
    private FragmentCalendar fragmentCalendar = new FragmentCalendar();
    private FragmentHome fragmentHome = new FragmentHome();
    private FragmentStatistic fragmentStatistic = new FragmentStatistic();
    private FragmentTimetable fragmentTimetable = new FragmentTimetable();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.frameLayout, fragmentHome).commitNowAllowingStateLoss(); // 처음 실행시 홈 프래그먼트가 나오도록 설정
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        bottomNavigationView.setSelectedItemId(R.id.homeItem); //처음 실행시 BottomNavigationView가 홈 아이콘을 표시하도록 설정
        bottomNavigationView.setOnNavigationItemSelectedListener(new ItemSelectedListener());//메뉴 클릭에 대한 이벤트 처리


    }

    class ItemSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener{

        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {//메뉴 클릭시 발생하는 이벤트 실행
            FragmentTransaction transaction = fragmentManager.beginTransaction();

            switch(menuItem.getItemId())//menuItem에 설정했던 메뉴들의 아이디를 찾아서 매치해보고 맞으면 프래그먼트 변경
            {
                case R.id.calendarItem:
                    transaction.replace(R.id.frameLayout, fragmentCalendar).commitAllowingStateLoss();//프래그먼트 변경
                    break;

                case R.id.homeItem:
                    transaction.replace(R.id.frameLayout, fragmentHome).commitAllowingStateLoss();
                    break;

                case R.id.statisticItem:
                    transaction.replace(R.id.frameLayout, fragmentStatistic).commitAllowingStateLoss();
                    break;

                case R.id.timetableItem:
                    transaction.replace(R.id.frameLayout, fragmentTimetable).commitAllowingStateLoss();
                    break;
            }
            return true;
            }
    }


}
